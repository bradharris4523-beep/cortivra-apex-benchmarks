# Cortivra-Apex Universal Silicon 1-Click Installer & Hardware Verifier (Windows PowerShell)
param(
    [string]$LicenseKey = ""
)
$ErrorActionPreference = "Stop"
Get-ChildItem -LiteralPath $PSScriptRoot -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$env:PYTHONPATH = $PSScriptRoot
Write-Host "=== Cortivra-Apex v2.0.0 Universal Silicon Installer ===" -ForegroundColor Cyan
python -c "import torch, numpy, scipy" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "[Cortivra-Apex] Installing required GPU runtime libraries (torch, numpy, scipy)..." -ForegroundColor Yellow
    python -m pip install --disable-pip-version-check "torch>=2.2" "numpy>=1.24" "scipy>=1.11"
}
python -m cortivra_apex verify
if ($LicenseKey -ne "") {
    python -m cortivra_apex activate --key "$LicenseKey"
}
$startupDir = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
if (Test-Path $startupDir) {
    $cmdContent = "@echo off`r`nset `"PYTHONPATH=$PSScriptRoot`"`r`nstart `"`" /B pythonw -m cortivra_apex daemon --port 7860 >nul 2>&1`r`n"
    Set-Content -Path (Join-Path $startupDir "Cortivra-Apex-Guardian.cmd") -Value $cmdContent -Encoding Ascii -Force
}
Write-Host "Cortivra-Apex verified and ready (Dormant-Until-Needed Guardian active)." -ForegroundColor Green
