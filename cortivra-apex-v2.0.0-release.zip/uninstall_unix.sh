#!/usr/bin/env bash
# Cortivra-Apex v2.0.0 Clean Endpoint Uninstaller (macOS & Linux)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="${SCRIPT_DIR}"
echo "==================================================================="
echo "  Cortivra-Apex v2.0.0 -- Clean Endpoint Uninstaller (macOS/Linux)"
echo "==================================================================="
rm -f "${HOME}/Library/LaunchAgents/com.cortivra.apex.guardian.plist" 2>/dev/null || true
rm -f "${HOME}/.config/systemd/user/cortivra-apex.service" 2>/dev/null || true
python3 -m cortivra_apex uninstall >/dev/null 2>&1 || python3 "${SCRIPT_DIR}/cortivra-apex.pyz" uninstall >/dev/null 2>&1 || true
echo "[OK] Removed Cortivra-Apex auto-start service and Python site-packages autoload hook."
echo "     You may now safely delete this directory."
