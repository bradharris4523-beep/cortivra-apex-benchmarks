@echo off
title Cortivra-Apex v2.0.0 Clean Uninstaller (Windows)
setlocal
set "PYTHONPATH=%~dp0"
echo ===================================================================
echo   Cortivra-Apex v2.0.0 -- Clean Endpoint Uninstaller (Windows)
echo ===================================================================
set "STARTUP_CMD=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Cortivra-Apex-Guardian.cmd"
if exist "%STARTUP_CMD%" del /F /Q "%STARTUP_CMD%" >nul 2>&1
if exist "%~dp0Cortivra-Apex.exe" (
    "%~dp0Cortivra-Apex.exe" uninstall >nul 2>&1
) else (
    python -m cortivra_apex uninstall >nul 2>&1
)
echo [OK] Removed Cortivra-Apex Windows Startup entry and Python site-packages autoload hook.
echo      You may now safely delete this folder.
if not "%1"=="--non-interactive" pause
