#!/usr/bin/env bash
# Cortivra-Apex Universal Silicon 1-Click Installer & Hardware Verifier (macOS / Linux)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
xattr -cr "${SCRIPT_DIR}" 2>/dev/null || true
export PYTHONPATH="${SCRIPT_DIR}"
echo "=== Cortivra-Apex v2.0.0 Universal Silicon Installer ==="
python3 -c "import torch, numpy, scipy" >/dev/null 2>&1 || python3 -m pip install --disable-pip-version-check "torch>=2.2" "numpy>=1.24" "scipy>=1.11"
python3 -m cortivra_apex verify
if [ "${1:-}" != "" ]; then
    python3 -m cortivra_apex activate --key "$1"
fi
echo "Cortivra-Apex verified and ready (Dormant-Until-Needed Guardian active)."
