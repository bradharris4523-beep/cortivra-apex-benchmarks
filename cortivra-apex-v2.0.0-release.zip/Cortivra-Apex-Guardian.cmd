@echo off
set "PYTHONPATH=%~dp0"
if exist "%~dp0Cortivra-Apex.exe" (
    start "" /B "%~dp0Cortivra-Apex.exe" daemon --port 7860 >nul 2>&1
) else (
    start "" /B pythonw -m cortivra_apex daemon --port 7860 >nul 2>&1
)
