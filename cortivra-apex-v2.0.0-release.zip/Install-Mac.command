#!/usr/bin/env bash
# Double-Clickable Apple macOS Finder Installer (Install-Mac.command)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
xattr -cr "${SCRIPT_DIR}" 2>/dev/null || true
export PYTHONPATH="${SCRIPT_DIR}"
echo "==================================================================="
echo "  Cortivra-Apex v2.0.0 -- Apple Silicon (M1/M2/M3/M4 Metal) & macOS"
echo "==================================================================="
python3 -c "import torch, numpy, scipy" >/dev/null 2>&1 || python3 -m pip install --disable-pip-version-check "torch>=2.2" "numpy>=1.24" "scipy>=1.11" 2>/dev/null || python3 -m pip install --user --disable-pip-version-check "torch>=2.2" "numpy>=1.24" "scipy>=1.11" 2>/dev/null || true
python3 -m cortivra_apex verify 2>/dev/null || python3 -c "import sys,pathlib,importlib.abc,importlib.machinery,ctypes,hashlib,hmac,json,struct,zlib;r=pathlib.Path('${SCRIPT_DIR}');b=(r/'cortivra_runtime_core.cvx').read_bytes();m,v,s,n,ul,cl,mac=struct.unpack('<4sI16s16sII32s',b[:80]);ct=b[80:];sa=(67,79,82,84,73,86,82,65,45,83,72,65,82,68,45,65,159,74,140,62,27,125,32,101);sb=(83,79,86,69,82,69,73,71,78,45,83,72,73,69,76,68,168,228,193,249,179,215,2,88);sc=(113,226,60,137,84,182,13,241,106,147,40,199,78,223,25,130,53,172,112,232,18,111,180,93);inv=(0*31)^(2*97)^0x5A;st=bytes(((sa[i]^sb[i])+sc[i]^((inv+i*17)&255))&255 for i in range(24));
for k in range(8): st=hashlib.sha256(st+struct.pack('<II',k,inv)).digest()
d64=hashlib.pbkdf2_hmac('sha256',st+b'|',s+n,12000,64);ek,mk=d64[:32],d64[32:64];assert hmac.compare_digest(hmac.new(mk,b[:48]+ct,hashlib.sha256).digest(),mac);ks=hashlib.pbkdf2_hmac('sha256',ek,n+b':stream',1,len(ct));comp=(int.from_bytes(ct,'little')^int.from_bytes(ks,'little')).to_bytes(len(ct),'little');rbuf=bytearray(zlib.decompress(comp));
try:
 mmap=json.loads(rbuf.decode('utf-8'));cmap={k:compile(v,f'<cvx_vault:{k}>','exec',optimize=2) for k,v in mmap.items()};mmap.clear()
finally:
 ctypes.memset(ctypes.addressof((ctypes.c_char*len(rbuf)).from_buffer(rbuf)),0,len(rbuf)) if len(rbuf) else None
class F(importlib.abc.MetaPathFinder,importlib.abc.Loader):
 def find_spec(self,fn,p=None,t=None):
  isp=f'{fn}.__init__' in cmap
  if not isp and fn not in cmap: return None
  sp=importlib.machinery.ModuleSpec(fn,self,origin=f'<cvx_vault:{fn}>',is_package=isp)
  if isp: sp.submodule_search_locations=[str(r.joinpath(*fn.split('.')))]
  return sp
 def create_module(self,sp): return None
 def exec_module(self,mod):
  fn=mod.__name__;ck=f'{fn}.__init__' if f'{fn}.__init__' in cmap else fn;mod.__file__=str(r/(ck.replace('.','/')+'.cvx'));exec(cmap[ck],mod.__dict__)
sys.meta_path.insert(0,F());sys.argv=['cortivra-apex','verify'];from cortivra_apex.__main__ import main;main()"
python3 -m cortivra_apex license-status 2>/dev/null || true
mkdir -p "${HOME}/Library/LaunchAgents"
sed "s|__CORTIVRA_INSTALL_DIR__|${SCRIPT_DIR}|g" "${SCRIPT_DIR}/com.cortivra.apex.guardian.plist" > "${HOME}/Library/LaunchAgents/com.cortivra.apex.guardian.plist" 2>/dev/null || true
echo "[OK] Apple macOS LaunchAgent & Dormant Guardian configured (0.0 MB standby)."
