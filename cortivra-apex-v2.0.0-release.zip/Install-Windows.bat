@echo off
title Cortivra-Apex v2.0.0 Universal Silicon Installer (Windows)
setlocal
set "PYTHONPATH=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1
echo ===================================================================
echo   Cortivra-Apex v2.0.0 -- Universal GPU Engine (Windows Installer)
echo ===================================================================
if exist "%~dp0Cortivra-Apex.exe" (
    "%~dp0Cortivra-Apex.exe" verify
    "%~dp0Cortivra-Apex.exe" license-status
) else (
    python -c "import torch, numpy, scipy" >nul 2>&1
    if errorlevel 1 (
        echo [Cortivra-Apex] First-time setup: installing GPU runtime libraries...
        python -m pip install --disable-pip-version-check "torch>=2.2" "numpy>=1.24" "scipy>=1.11"
    )
    python -m cortivra_apex verify
    python -m cortivra_apex license-status
)
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%STARTUP_DIR%" (
    (echo @echo off& echo set "PYTHONPATH=%~dp0"& echo if exist "%~dp0Cortivra-Apex.exe" ^(start "" /B "%~dp0Cortivra-Apex.exe" daemon --port 7860 ^>nul 2^>^&1^) else ^(del /F /Q "%%~f0" ^>nul 2^>^&1^)) > "%STARTUP_DIR%\Cortivra-Apex-Guardian.cmd" 2>nul
)
echo.
echo [OK] Hardware verified and Dormant-Until-Needed Guardian registered in Windows Startup (0.0 MB standby).
if not "%1"=="--non-interactive" pause
